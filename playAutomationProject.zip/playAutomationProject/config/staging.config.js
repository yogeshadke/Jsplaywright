export default {
  use: {
    baseURL: 'https://demoblaze.com/index.html',
    headless: false,
  },
};
